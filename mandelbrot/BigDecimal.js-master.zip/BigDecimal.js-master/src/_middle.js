return MathContext;
})();

var BigDecimal = (function (MathContext) {
