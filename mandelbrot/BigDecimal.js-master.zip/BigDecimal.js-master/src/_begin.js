(function () {

var MathContext = (function () {
